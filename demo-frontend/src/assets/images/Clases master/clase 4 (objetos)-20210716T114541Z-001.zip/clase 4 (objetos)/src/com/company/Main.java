package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        boolean menu = true;
        Rectangulo uno = new Rectangulo(-2 , -5);
        Scanner sc = new Scanner(System.in);
        while (menu) {
            System.out.println("Elige una opción ");
            System.out.println("1 - Introducir rectángulo");
            System.out.println("2 - calcular área");
            System.out.println("0 - salir");

            String opcion = sc.nextLine();
            switch (opcion){
                case "1" :
                    System.out.println("introduce anchura");
                    String anchura = sc.nextLine();
                    System.out.println("introduce altura");
                    String altura = sc.nextLine();
                    uno.setAnchura(Integer.parseInt(anchura));
                    uno.setAltura(Integer.parseInt(altura));
                    System.out.println("la anchura vale esto: " + uno.getAnchura());
                    System.out.println(" la altura vale esto: " + uno.getAltura());
                    break;

                case "2" :
                    if (uno.getAnchura()== -2 && uno.getAltura() == -5) {
                        System.out.println("hacer primero paso 1");

                    } else {System.out.println(uno.calcularArea());
                    }



                    break;
                case "0" :
                    menu = false;
                    break;
                default:
                    System.out.println("introduce una opcion correcta");
                    break;
            }
        }




    }
}

