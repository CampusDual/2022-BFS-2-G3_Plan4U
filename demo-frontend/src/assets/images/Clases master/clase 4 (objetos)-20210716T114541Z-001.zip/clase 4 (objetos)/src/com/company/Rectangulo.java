package com.company;

public class Rectangulo {

    private int anchura;
    private int altura;

    public Rectangulo(int anch , int alt ){
        this.anchura = anch;
        this.altura = alt;
    }

    public int getAltura (){
        return this.altura;
    }

    public int getAnchura() {
        return anchura;
    }

    public void setAnchura(int ancho){
        this.anchura = ancho ;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public int calcularArea (){
        int area = this.altura * this.anchura ;
        return area;
    }
}
