package com.company;

public class Main {

    public static void main(String[] args) {
        Perro perrouno = new Perro ("firulais" , "doberman");

        System.out.println(perrouno.getNombre());
        System.out.println(perrouno.getRaza());

        Adiestrador vacio = new Adiestrador();
        Adiestrador uno = new Adiestrador("Fulano" , "12345678S" , perrouno  ) ;


        System.out.println(uno.getNombre());

        System.out.println(vacio);
        System.out.println(uno.getFirulais().getRaza());







    }
}
