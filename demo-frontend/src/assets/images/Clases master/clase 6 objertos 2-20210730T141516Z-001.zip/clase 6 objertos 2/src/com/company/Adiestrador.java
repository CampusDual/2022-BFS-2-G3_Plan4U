package com.company;

public class Adiestrador {

    private String nombre ;
    private String dni;
    private Perro firulais;

    public Adiestrador (){}
    public Adiestrador (String nombre , String dni , Perro firulais) {
        this.nombre = nombre;
        this.dni = dni;
        this.firulais = firulais;

    }

    public void setFirulais(Perro firulais) {
        this.firulais = firulais;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public Perro getFirulais() {
        return firulais;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDni() {
        return dni;
    }



}
