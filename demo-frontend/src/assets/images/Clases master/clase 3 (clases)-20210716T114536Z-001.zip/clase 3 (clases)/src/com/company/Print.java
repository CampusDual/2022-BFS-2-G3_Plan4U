package com.company;

public class Print {


    public static int  calcularDoble (int numero){
        numero = numero * 2;
      return numero;
    }
}
