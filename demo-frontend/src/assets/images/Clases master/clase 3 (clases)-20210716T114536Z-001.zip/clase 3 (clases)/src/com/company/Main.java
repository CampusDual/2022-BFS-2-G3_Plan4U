package com.company;

import java.util.Scanner;

import static com.company.Print.calcularDoble;

public class Main {

    public static void main(String[] args) {
        System.out.println("hola mundo");
        int numero = calcularDoble(4);
        System.out.println(numero);
    }

}
