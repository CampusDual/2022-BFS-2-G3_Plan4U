/*
 * Proyecto de Programación II.
 * Gestión de un banco (entidad bancaria). 
 */
package es.uvigo.esei.pro2.ui;
/**
 *
 * @author nrufino
 */

public class Main {
    public static void main(String[] args)
    {
        new Ilc().ler();
    }
}