/*
 * Definicion de la clase Cliente
 */
package es.uvigo.esei.pro2.core;

/**
 *
 * @author nrufino
 */
public class Cliente {

    private String dni; // D.N.I. del cliente
    private String nombre;  // Nombre completo del cliente
    private String domicilio;  // Domicilio del cliente

    private Cuenta[] cuentas; // Cuentas del cliente
    private int numCuentas; // Numero de cuentas que posee el cliente

    /**
     * Crea un nuevo cliente, con sus datos: nombre, domicilio y aÃ±o
     *
     * @param d D.N.I. del cliente
     * @param nombre nombre completo del cliente
     * @param domicilio el domicilio del cliente
     * @param numCuentas numero de cuentas que tiene el cliente
     */
    public Cliente(String d, String nombre, String domicilio,
            int numCuentas) {
        this.setDni(d);
        this.setNombre(nombre);
        this.setDomicilio(domicilio);
        this.setNumCuentas(numCuentas);
    }

    /**
     * Devuelve el D.N.I. del cliente
     *
     * @return el dni del cliente, como String.
     */
    public String getDni() {
        return dni;
    }

    /**
     * Cambia el D.N.I.del cliente
     *
     * @param d el dni del cliente
     */
    public void setDni(String d) {
        dni = d;
    }

    /**
     * Devuelve el nombre del cliente
     *
     * @return El valor como cadena
     *
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Cambia el nombre del cliente
     *
     * @param nombre El nuevo valor, como cadena
     */
    public void setNombre(String nombre) {
        this.nombre = nombre.trim();
    }

    /**
     * Devuelve el domicilio del cliente
     *
     * @return El valor como cadena
     *
     */
    public String getDomicilio() {
        return domicilio;
    }

    /**
     * Cambia el domicilio del cliente
     *
     * @param domicilio El nuevo valor, como cadena
     */
    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio.trim();
    }

    /**
     * Devuelve el número de cuentas que tiene el cliente
     *
     * @return el número de cuentas, como int.
     */
    public int getNumCuentas() {
        return numCuentas;
    }

    /**
     * Cambia el número de cuentas que tine el cliente
     *
     * @param numCuentas El nuevo valor, como int.
     */
    public void setNumCuentas(int numCuentas) {
        this.numCuentas = numCuentas;
        cuentas = new Cuenta[numCuentas];
        for (int i = 0; i < numCuentas; i++) {
            Cuenta cu = new Cuenta("", 0);
            cuentas[i] = cu;
        }
    }

    /**
     * Devuelve la cuenta especificada por el índice
     *
     * @param pos la posición de la cuenta a obtener, como int
     * @return la cuenta especificada, como Cuenta.
     */
    public Cuenta getCuenta(int pos) {
        if (pos >= getNumCuentas()) {
            System.err.println("getCuenta(): sobrepasa la pos: " + (pos + 1)
                    + " / " + getNumCuentas());
            System.exit(-1);
        }
        return cuentas[pos];
    }

    /**
     * Cambia la cuenta espcificada por el índice
     *
     * @param pos la posición de la cuenta a modificar, como int
     * @param cu el nuevo valor de la cuenta, como cuenta
     */
    public void setCuenta(int pos, Cuenta cu) {
        if (pos >= getNumCuentas()) {
            System.err.println("setCuenta(): sobrepasa la pos: " + (pos + 1)
                    + " / " + getNumCuentas());
            System.exit(-1);
        }
        cuentas[pos] = cu;
    }

    /**
     * Proporciona todos los datos del cliente
     *
     * @return El valor como cadena
     */
    public String toString() {
        String toret = "Datos del cliente: " + getDni() + " ; " 
                + getNombre() + " ; " + getDomicilio() + " \n "
                + "\tDatos de sus cuentas:  ";

        for (int i = 0; i < getNumCuentas(); i++) {
            toret +=  "\n\t\t" + cuentas[i].toString() ;
        }

        return toret;
    }

}
