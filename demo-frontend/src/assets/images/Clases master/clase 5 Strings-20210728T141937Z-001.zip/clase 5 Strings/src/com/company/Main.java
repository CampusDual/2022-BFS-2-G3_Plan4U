package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("introduce nombre");
        String nombre = scan.nextLine();

        System.out.println("introduce dni");
        String dni = scan.nextLine();

        Persona uno = new Persona( nombre , dni);


        if (dni.isEmpty()){
            System.out.println("dni erroneo");
        }  else {
            if (dni.length() == 8) {
                System.out.println(dni.substring(7 , 8));
            }

        }
        System.out.println(esPalindrimo("qwerty"));
        System.out.println(esPalindrimo("reconocer"));
        System.out.println(esPalindrimo("12344321"));
        System.out.println(esPalindrimo("gdsajo"));

        System.out.println(isPalindrome("sdafasdfasd"));

    }
    public static boolean esPalindrimo (String palin) {
        int contador = 1 ;
        boolean palindro = true;
        while (contador <= palin.length() && palindro ){
            int adelante_start =  contador-1;
            int adelante_end = contador;
            int atras_start = palin.length()-(contador);
            int atras_end = palin.length()-(contador-1);
             palindro = palin.substring(adelante_start  ,adelante_end ) .equals(palin.substring(atras_start , atras_end));
            contador++;
        }
        return palindro ;
    }

    public static boolean isPalindrome(String palin){
        String delReves = "";
        boolean palindromo = false;
        for(int i = 0 ; i < palin.length(); i++){
            delReves = delReves + palin.substring(palin.length()-(i+1), palin.length()-i);
        }
        if (delReves.equals(palin)){
            palindromo = true;
        }
        return palindromo;
    }
}
